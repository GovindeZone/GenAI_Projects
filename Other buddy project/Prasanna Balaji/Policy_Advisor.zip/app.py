import streamlit as st
import pandas as pd
from insurers import INSURERS
from scorer import score_insurer

st.set_page_config(
    page_title="Health Insurance RAG Advisor",
    layout="wide"
)

st.title("🏥 AI Health Insurance Advisor")

st.markdown("Get insurer recommendations based on customer preferences")

# Preferences
st.sidebar.header("Customer Preferences")

pregnancy = st.sidebar.checkbox("Pregnancy / Maternity Coverage")
day1_coverage = st.sidebar.checkbox("Coverage from Day 1")
ped = st.sidebar.checkbox("Pre-existing Disease Coverage")
cashless = st.sidebar.checkbox("Large Cashless Hospital Network")
no_room_rent_cap = st.sidebar.checkbox("No Room Rent Cap")

preferences = {
    "pregnancy": pregnancy,
    "day1_coverage": day1_coverage,
    "ped": ped,
    "cashless": cashless,
    "no_room_rent_cap": no_room_rent_cap
}

if st.button("Find Best Policies"):

    results = []

    with st.spinner("Analyzing policies using RAG..."):
        for insurer in INSURERS:
            score, explanation = score_insurer(
                insurer,
                preferences
            )

            results.append({
                "Insurer": insurer,
                "Score": score,
                "Why": ", ".join(explanation)
            })

    df = pd.DataFrame(results)
    df = df.sort_values(by="Score", ascending=False)

    st.subheader("Ranked Recommendations")
    st.dataframe(df)

    st.bar_chart(df.set_index("Insurer")["Score"])

    top = df.iloc[0]

    st.success(
        f"Best Match: {top['Insurer']}\n\nReason: {top['Why']}"
    )