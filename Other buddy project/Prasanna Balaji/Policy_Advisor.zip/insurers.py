INSURERS = [
    "HDFC ERGO",
    "ICICI Lombard",
    "Star Health",
    "Care Health",
    "Niva Bupa"
]