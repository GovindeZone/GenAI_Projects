from rag_engine import retrieve


def score_insurer(insurer, preferences):
    score = 0
    explanation = []

    context = retrieve(f"{insurer} health insurance policy terms")

    if preferences["pregnancy"] and "maternity" in context.lower():
        score += 20
        explanation.append("Supports maternity coverage")

    if preferences["day1_coverage"] and "day 1" in context.lower():
        score += 25
        explanation.append("Offers day-1 coverage")

    if preferences["ped"] and "pre-existing" in context.lower():
        score += 15
        explanation.append("Pre-existing disease support")

    if preferences["cashless"]:
        if "cashless" in context.lower():
            score += 15
            explanation.append("Strong cashless network")

    if preferences["no_room_rent_cap"]:
        if "room rent sub-limit" not in context.lower():
            score += 15
            explanation.append("No room rent cap")

    return score, explanation