from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings

DB_PATH = "vectorstore"

vectordb = Chroma(
    persist_directory=DB_PATH,
    embedding_function=OpenAIEmbeddings()
)

retriever = vectordb.as_retriever(search_kwargs={"k": 8})


def retrieve(query):
    docs = retriever.invoke(query)
    return "\n".join([doc.page_content for doc in docs])